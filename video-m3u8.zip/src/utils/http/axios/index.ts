// axios配置  可自行根据项目进行更改，只需更改该文件即可，其他文件可以不动

import { VAxios } from './Axios';
import { AxiosTransform } from './axiosTransform';
import { AxiosResponse } from 'axios';
import { checkStatus } from './checkStatus';
import {  Toast as Message } from "vant";
import { RequestEnum, ResultEnum, ContentTypeEnum } from '../httpEnum';

import { isString } from '/@/utils/is';
import { setObjToUrlParams } from '/@/utils/urlUtils';

import { RequestOptions, Result } from './types';

// const isDev = process.env.NODE_ENV === 'development'

const isDev = import.meta.env.DEV
const produrl = VITE_BASE_API
const prefix = isDev ? import.meta.env.VITE_BASE_API : produrl


const transform: AxiosTransform = {
    /**
     * @description: 处理请求数据
     */
    transformRequestData: (res: AxiosResponse<Result>, options: RequestOptions) => {
        const { isTransformRequestResult, isShowMessage = true, isShowErrorMessage, isShowSuccessMessage, successMessageText, errorMessageText } = options;
        if(!res) return

        const reject = Promise.reject

        const { data,status } = res;
        if(!data) return
        //  这里 code，result，message为 后台统一的字段，需要在 types.ts内修改为项目自己的接口返回格式
        const { state:resultType,msg,success } = data;

        // 请求成功
        const hasSuccess = data && Reflect.has(data, 'state') && resultType === ResultEnum.SUCCESS;

        // 是否显示提示信息
        if (isShowMessage) {
            if (hasSuccess && (successMessageText || isShowSuccessMessage)) { // 是否显示自定义信息提示
                Message.success(successMessageText || msg || '操作成功！')
            } else if (!hasSuccess && (errorMessageText || isShowErrorMessage)) { // 是否显示自定义信息提示
                Message.fail(msg || errorMessageText || '操作失败！')
            } else if (!hasSuccess && options.errorMessageMode === 'modal') { // errorMessageMode=‘custom-modal’的时候会显示modal错误弹窗，而不是消息提示，用于一些比较重要的错误
                Message.fail(msg || errorMessageText || '错误提示！')
            }
        }
        
        // 不进行任何处理，直接返回
        // 用于页面代码可能需要直接获取code，data，message这些信息时开启
        if (!isTransformRequestResult) {
            return res.data;
        }

        if (!data) {
            // return '[HTTP] Request has no return value';
            return reject(data);
        }

        // 接口请求成功，直接返回结果
        if (resultType === ResultEnum.SUCCESS || status === 200) {
            return { data };
        }
        // 接口请求错误，统一提示错误信息
        if (status === ResultEnum.ERROR) {
            if (msg) {
                Message.fail(data.msg);
                Promise.reject(new Error(msg));
            } else {
                const msg = '操作失败,系统异常!';
                Message.fail(msg);
                Promise.reject(new Error(msg));
            }
            return reject();
        }


        // 这里逻辑可以根据项目进行修改
        if (!hasSuccess) {
            return reject(new Error(msg));
        }

        return data;
    },

    // 请求之前处理config
    beforeRequestHook: (config, options) => {
        // const { apiUrl, joinPrefix, joinParamsToUrl, formatDate, isParseToJson } = options;
        const { apiUrl, joinParamsToUrl} = options;

        // console.log(`是否为开发环境${isDev}地址${apiUrl}`);
        config.url = isDev ? `${config.url}` : `${apiUrl || ''}${config.url}`;

        if (config.method === RequestEnum.GET) {
            const now = new Date().getTime();
            if (!isString(config.params)) {
                config.data = {
                    // 给 get 请求加上时间戳参数，避免从缓存中拿数据。
                    params: Object.assign(config.params || {}, {
                        _t: now,
                    }),
                };
            } else {
                // 兼容restful风格
                config.url = config.url + config.params + `?_t=${now}`;
                config.params = {};
            }
        } else {
            if (!isString(config.params)) {
                config.data = config.params;
                config.params = {};
                if (joinParamsToUrl) {
                    config.url = setObjToUrlParams(config.url as string, config.data);
                }
            } else {
                // 兼容restful风格
                config.url = config.url + config.params;
                config.params = {};
            }
            // 'a[]=b&a[]=c'
            // if (!isParseToJson) {
            //     config.params = qs.stringify(config.params, { arrayFormat: 'brackets' })
            //     config.data = qs.stringify(config.data, { arrayFormat: 'brackets' })
            // }
        }
        return config;
    },

    /**
     * @description: 请求拦截器处理
     */
    requestInterceptors: (config:any) => {
        // const store = UserInfoStore()
        // // 请求之前处理config
        // const token = store.token;
        
        // if (token) {
        //     // jwt token
        //     config.headers.Authorization = token;
        //     config.headers.common['Authorization']= token;
        //     config.headers.common['Authorization'] = 'Bearer ' + token;
        // } 
        return config;
    },

    /**
     * @description: 响应错误处理
     */
    responseInterceptorsCatch: (error: any) => {
        const { response, code, message } = error || {};
        const msg: string =
            response && response.data && response.data.error ? response.data.error.message : '';
        const err: string = error.toString();
        try {
            if (code === 'ECONNABORTED' && message.indexOf('timeout') !== -1) {
                Message.fail('接口请求超时,请刷新页面重试!');
                return;
            }
            if (err && err.includes('Network Error')) {
                Message.fail('请检查您的网络连接是否正常,请刷新页面重试!');
                return;
            }
        } catch (error:any) {
            throw new Error(error);
        }
        // 请求是否被取消
        const isCancel = (error as any).__CANCEL__
        if (!isCancel) {
            checkStatus(error.response && error.response.status, msg);
        } else {
            console.warn(error, '请求被取消！')
        }
        return error;
    },
};



const axios = new VAxios({
    timeout: 15 * 1000,
    // 基础接口地址
    // baseURL: process.env.VUE_APP_API_URL,
    // 接口可能会有通用的地址部分，可以统一抽取出来
    prefixUrl: prefix,
    headers: { 'Content-Type': ContentTypeEnum.JSON},
    
    // 数据处理方式
    transform,
    // 配置项，下面的选项都可以在独立的接口请求中覆盖
    requestOptions: {
        // 默认将prefix 添加到url
        joinPrefix: true,
        // 需要对返回数据进行处理
        isTransformRequestResult: true,
        // post请求的时候添加参数到url
        joinParamsToUrl: false,
        // 格式化提交参数时间
        formatDate: true,
        // 消息提示类型
        errorMessageMode: 'none',
        // 接口地址
        // apiUrl: process.env.VUE_APP_API_URL,
    },
    withCredentials: false
});


export default axios;
