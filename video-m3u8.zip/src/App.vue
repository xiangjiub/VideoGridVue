<script setup lang="ts">

import Index from '/@/views/Xindex.vue'
</script>

<template>
  <router-view></router-view>
</template>

