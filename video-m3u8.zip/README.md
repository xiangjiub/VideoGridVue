# Vue 3 + Typescript + Vite


###  安装依赖
npm i

### 运行
npm run dev

### 打包
npm run build


###  资料
https://blog.csdn.net/weixin_45753961/article/details/117561893

